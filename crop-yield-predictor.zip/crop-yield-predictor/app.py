"""
Crop Yield Predictor — Streamlit Web App
------------------------------------------
BEFORE YOU RUN THIS:
  1. Install dependencies:
       pip install streamlit pandas scikit-learn
  2. Make sure "crop_yield_data.csv" is in this same folder.
  3. Run with:
       streamlit run app.py
     (NOT "python app.py" — Streamlit apps must be launched with the
     "streamlit run" command.)
"""

import pandas as pd
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error

# ---------------------------------------------------------------------------
# Page config + styling — Earth & Harvest theme
# ---------------------------------------------------------------------------

st.set_page_config(page_title="Crop Yield Predictor", page_icon="🌾", layout="wide")

st.markdown("""
<style>
    .stApp { background-color: #16201A; }
    section[data-testid="stSidebar"] { background-color: #1D2B22; }
    div[data-testid="stMetric"] {
        background-color: #1D2B22;
        border: 1px solid #35452F;
        border-radius: 10px;
        padding: 16px;
    }
    div.stButton > button {
        background-color: #7FA650;
        color: #16201A;
        font-weight: 600;
        border: none;
    }
    div.stButton > button:hover {
        background-color: #94BB63;
        color: #16201A;
    }
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Train the model (cached so it only trains once per session)
# ---------------------------------------------------------------------------

@st.cache_resource
def load_model():
    data = pd.read_csv("crop_yield_data.csv")

    X = data[["Rainfall", "Temperature", "Fertilizer", "Area"]]
    y = data["Yield"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    r2 = r2_score(y_test, preds)
    mae = mean_absolute_error(y_test, preds)

    importances = dict(zip(X.columns, model.feature_importances_))

    return model, r2, mae, len(data), importances, data


model, r2, mae, n_rows, importances, data = load_model()


# ---------------------------------------------------------------------------
# Sidebar — Model Control
# ---------------------------------------------------------------------------

with st.sidebar:
    st.markdown("## 🌾 Model Control")
    st.markdown("### Model Info")
    st.markdown("🔹 **Algorithm:** Random Forest Regressor")
    st.markdown("🔹 **Trees:** 100 estimators")
    st.markdown(f"🔹 **Dataset:** {n_rows} field records")
    st.markdown(f"🔹 **R² Score:** {r2:.3f}")
    st.markdown(f"🔹 **Mean Abs. Error:** {mae:.2f} tons/hectare")

    st.markdown("---")
    st.markdown("### Feature Importance")
    for feat, imp in sorted(importances.items(), key=lambda x: -x[1]):
        st.markdown(f"**{feat}**")
        st.progress(float(imp))

    st.markdown("---")
    st.markdown("### Dataset Ranges")
    st.markdown(f"🌧️ Rainfall: {data['Rainfall'].min():.0f}–{data['Rainfall'].max():.0f} mm")
    st.markdown(f"🌡️ Temperature: {data['Temperature'].min():.0f}–{data['Temperature'].max():.0f} °C")
    st.markdown(f"🧪 Fertilizer: {data['Fertilizer'].min():.0f}–{data['Fertilizer'].max():.0f} kg/ha")
    st.markdown(f"📐 Area: {data['Area'].min():.1f}–{data['Area'].max():.1f} ha")


# ---------------------------------------------------------------------------
# Main panel
# ---------------------------------------------------------------------------

st.title("Crop Yield Predictor")
st.caption("Enter field conditions below to estimate expected crop yield.")

st.markdown("---")

col1, col2 = st.columns([1, 1])

with col1:
    st.markdown("### Field Conditions")

    rainfall = st.slider(
        "Rainfall (mm)",
        min_value=float(data["Rainfall"].min()),
        max_value=float(data["Rainfall"].max()),
        value=float(data["Rainfall"].mean()),
        step=1.0,
    )

    temperature = st.slider(
        "Temperature (°C)",
        min_value=float(data["Temperature"].min()),
        max_value=float(data["Temperature"].max()),
        value=float(data["Temperature"].mean()),
        step=0.1,
    )

    fertilizer = st.slider(
        "Fertilizer Used (kg/hectare)",
        min_value=float(data["Fertilizer"].min()),
        max_value=float(data["Fertilizer"].max()),
        value=float(data["Fertilizer"].mean()),
        step=1.0,
    )

    area = st.slider(
        "Area (hectares)",
        min_value=float(data["Area"].min()),
        max_value=float(data["Area"].max()),
        value=float(data["Area"].mean()),
        step=0.1,
    )

    predict_clicked = st.button("🌱 Predict Yield", type="primary")

with col2:
    st.markdown("### Prediction")

    if predict_clicked:
        new_data = [[rainfall, temperature, fertilizer, area]]
        result = model.predict(new_data)[0]

        st.success(f"Predicted Crop Yield: **{result:.2f} tons/hectare**")

        total_output = result * area
        st.metric("Estimated Total Output", f"{total_output:.1f} tons", help="Predicted yield × area entered")

        st.markdown("---")
        st.markdown("**Inputs used**")
        st.markdown(f"- Rainfall: {rainfall:.0f} mm")
        st.markdown(f"- Temperature: {temperature:.1f} °C")
        st.markdown(f"- Fertilizer: {fertilizer:.0f} kg/hectare")
        st.markdown(f"- Area: {area:.2f} hectares")
    else:
        st.caption("Set field conditions and click Predict Yield to see a result.")

st.markdown("---")
st.caption(f"Model R² score: {r2:.3f} · Mean absolute error: {mae:.2f} tons/hectare · trained on {n_rows} records")
