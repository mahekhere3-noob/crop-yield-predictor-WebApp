# Crop Yield Predictor — Streamlit App

Run it:
    pip install streamlit pandas scikit-learn
    streamlit run app.py

Model trains once on startup (cached) — Random Forest Regressor
on crop_yield_data.csv, predicting Yield (tons/hectare) from
Rainfall, Temperature, Fertilizer, and Area.
